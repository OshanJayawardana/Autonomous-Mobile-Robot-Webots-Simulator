This is a PROTO file for four wheeled robot that is used in the Braintenberg Vehicle Webots Tutorial.

Tutorial video link: 

